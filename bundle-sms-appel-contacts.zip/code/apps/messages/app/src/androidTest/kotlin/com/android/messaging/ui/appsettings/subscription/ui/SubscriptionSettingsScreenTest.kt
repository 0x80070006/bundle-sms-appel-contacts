package com.android.messaging.ui.appsettings.subscription.ui

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import com.android.messaging.R
import com.android.messaging.data.subscription.model.SubId
import com.android.messaging.ui.appsettings.subscription.model.PhoneNumberDialogUiState
import com.android.messaging.ui.appsettings.subscription.model.SubscriptionSettingsAction as Action
import com.android.messaging.ui.appsettings.subscription.model.SubscriptionUiState
import com.android.messaging.ui.core.AppTheme
import io.mockk.mockk
import io.mockk.verify
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class SubscriptionSettingsScreenTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<ComponentActivity>()

    private lateinit var onAction: (Action) -> Unit

    @Before
    fun setup() {
        onAction = mockk(relaxed = true)
    }

    @Test
    fun mmsCategoryHeader_isDisplayed() {
        setContent(subscriptionSettings = createDefaultSubscription())

        val mmsTitle = composeTestRule.activity.getString(
            R.string.mms_messaging_category_pref_title,
        )
        composeTestRule.onNodeWithText(mmsTitle).assertIsDisplayed()
    }

    @Test
    fun groupMms_shownWhenSupported() {
        val sub = createDefaultSubscription(isGroupMmsSupported = true)
        setContent(subscriptionSettings = sub)

        val groupMmsTitle = composeTestRule.activity.getString(R.string.group_mms_pref_title)
        composeTestRule.onNodeWithText(groupMmsTitle).assertIsDisplayed()
    }

    @Test
    fun groupMms_hiddenWhenNotSupported() {
        val sub = createDefaultSubscription(isGroupMmsSupported = false)
        setContent(subscriptionSettings = sub)

        val groupMmsTitle = composeTestRule.activity.getString(R.string.group_mms_pref_title)
        composeTestRule.onNodeWithText(groupMmsTitle).assertDoesNotExist()
    }

    @Test
    fun groupMmsClick_showsDialog() {
        val sub = createDefaultSubscription(
            isGroupMmsSupported = true,
            isDefaultSmsApp = true,
        )
        setContent(subscriptionSettings = sub)

        val groupMmsTitle = composeTestRule.activity.getString(R.string.group_mms_pref_title)
        composeTestRule.onNodeWithText(groupMmsTitle).performClick()
        composeTestRule.waitForIdle()

        val disableLabel = composeTestRule.activity.getString(R.string.disable_group_mms)
        composeTestRule.onNodeWithText(disableLabel).assertIsDisplayed()

        val okText = composeTestRule.activity.getString(android.R.string.ok)
        composeTestRule.onNodeWithText(okText).assertIsDisplayed()

        val cancelText = composeTestRule.activity.getString(android.R.string.cancel)
        composeTestRule.onNodeWithText(cancelText).assertIsDisplayed()
    }

    @Test
    fun phoneNumberItem_displaysCurrentNumber() {
        val sub = createDefaultSubscription(displayDetail = "+1234567890")
        setContent(subscriptionSettings = sub)

        composeTestRule.onNodeWithText("+1234567890").assertIsDisplayed()
    }

    @Test
    fun phoneNumberClick_reportsTheClick() {
        val sub = createDefaultSubscription(phoneNumber = "+1234567890")
        setContent(subscriptionSettings = sub)

        val phoneTitle = composeTestRule.activity.getString(R.string.mms_phone_number_pref_title)
        composeTestRule.onNodeWithText(phoneTitle).performClick()
        composeTestRule.waitForIdle()

        verify { onAction(Action.PhoneNumberClicked) }
    }

    @Test
    fun visiblePhoneNumberDialogState_showsDialog() {
        val sub = createDefaultSubscription(phoneNumber = "+1234567890")
        setContent(
            subscriptionSettings = sub,
            phoneNumberDialogState = PhoneNumberDialogUiState(isVisible = true),
        )

        val okText = composeTestRule.activity.getString(android.R.string.ok)
        composeTestRule.onNodeWithText(okText).assertIsDisplayed()
    }

    @Test
    fun autoRetrieveMms_toggleDelegatesToScreenModel() {
        val sub = createDefaultSubscription(
            isDefaultSmsApp = true,
            autoRetrieveMms = true,
        )
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.auto_retrieve_mms_pref_title)
        composeTestRule.onNodeWithText(title).performClick()

        verify(exactly = 1) {
            onAction(Action.AutoRetrieveMmsChanged(false))
        }
    }

    @Test
    fun autoRetrieveMmsWhenRoaming_disabledWhenAutoRetrieveOff() {
        val sub = createDefaultSubscription(
            isDefaultSmsApp = true,
            autoRetrieveMms = false,
        )
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(
            R.string.auto_retrieve_mms_when_roaming_pref_title,
        )
        composeTestRule.onNodeWithText(title).assertIsNotEnabled()
    }

    @Test
    fun autoRetrieveMmsWhenRoaming_enabledWhenAutoRetrieveOn() {
        val sub = createDefaultSubscription(
            isDefaultSmsApp = true,
            autoRetrieveMms = true,
        )
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(
            R.string.auto_retrieve_mms_when_roaming_pref_title,
        )
        composeTestRule.onNodeWithText(title).assertIsEnabled()
    }

    @Test
    fun deliveryReports_shownWhenSupported() {
        val sub = createDefaultSubscription(isDeliveryReportsSupported = true)
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.delivery_reports_pref_title)
        scrollToText(text = title)
        composeTestRule.onNodeWithText(title).assertIsDisplayed()
    }

    @Test
    fun deliveryReports_hiddenWhenNotSupported() {
        val sub = createDefaultSubscription(isDeliveryReportsSupported = false)
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.delivery_reports_pref_title)
        composeTestRule.onNodeWithText(title).assertDoesNotExist()
    }

    @Test
    fun deliveryReportsToggle_delegatesToScreenModel() {
        val sub = createDefaultSubscription(
            isDeliveryReportsSupported = true,
            isDefaultSmsApp = true,
            deliveryReportsEnabled = false,
        )
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.delivery_reports_pref_title)
        scrollToText(text = title)
        composeTestRule.onNodeWithText(title).performClick()

        verify(exactly = 1) {
            onAction(Action.DeliveryReportsChanged(true))
        }
    }

    @Test
    fun wirelessAlerts_shownWhenSupported() {
        val sub = createDefaultSubscription(isWirelessAlertsSupported = true)
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.wireless_alerts_title)
        scrollToText(text = title)
        composeTestRule.onNodeWithText(title).assertIsDisplayed()
    }

    @Test
    fun wirelessAlerts_hiddenWhenNotSupported() {
        val sub = createDefaultSubscription(isWirelessAlertsSupported = false)
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.wireless_alerts_title)
        composeTestRule.onNodeWithText(title).assertDoesNotExist()
    }

    @Test
    fun wirelessAlertsClick_delegatesToScreenModel() {
        val sub = createDefaultSubscription(isWirelessAlertsSupported = true)
        setContent(subscriptionSettings = sub)

        val title = composeTestRule.activity.getString(R.string.wireless_alerts_title)
        scrollToText(text = title)
        composeTestRule.onNodeWithText(title).performClick()

        verify(exactly = 1) {
            onAction(Action.WirelessAlertsClicked)
        }
    }

    @Test
    fun advancedCategory_shownWhenDeliveryReportsOrWirelessAlertsSupported() {
        val sub = createDefaultSubscription(
            isDeliveryReportsSupported = true,
            isWirelessAlertsSupported = false,
        )
        setContent(subscriptionSettings = sub)

        val advancedTitle =
            composeTestRule.activity.getString(R.string.advanced_category_pref_title)
        scrollToText(text = advancedTitle)
        composeTestRule.onNodeWithText(advancedTitle).assertIsDisplayed()
    }

    @Test
    fun advancedCategory_hiddenWhenNeitherSupported() {
        val sub = createDefaultSubscription(
            isDeliveryReportsSupported = false,
            isWirelessAlertsSupported = false,
        )
        setContent(subscriptionSettings = sub)

        val advancedTitle =
            composeTestRule.activity.getString(R.string.advanced_category_pref_title)
        composeTestRule.onNodeWithText(advancedTitle).assertDoesNotExist()
    }

    @Test
    fun settingsDisabled_whenNotDefaultSmsApp() {
        val sub = createDefaultSubscription(
            isDefaultSmsApp = false,
            isGroupMmsSupported = true,
            isDeliveryReportsSupported = true,
        )
        setContent(subscriptionSettings = sub)

        val groupMmsTitle = composeTestRule.activity.getString(R.string.group_mms_pref_title)
        composeTestRule.onNodeWithText(groupMmsTitle).assertIsNotEnabled()

        val autoRetrieveTitle = composeTestRule.activity.getString(
            R.string.auto_retrieve_mms_pref_title,
        )
        composeTestRule.onNodeWithText(autoRetrieveTitle).assertIsNotEnabled()

        val deliveryTitle = composeTestRule.activity.getString(R.string.delivery_reports_pref_title)
        scrollToText(text = deliveryTitle)
        composeTestRule.onNodeWithText(deliveryTitle).assertIsNotEnabled()
    }

    private fun scrollToText(text: String) {
        composeTestRule.onNode(hasScrollAction()).performScrollToNode(hasText(text))
    }

    private fun setContent(
        subscriptionSettings: SubscriptionUiState = createDefaultSubscription(),
        phoneNumberDialogState: PhoneNumberDialogUiState = PhoneNumberDialogUiState(),
    ) {
        composeTestRule.setContent {
            AppTheme {
                SubscriptionSettingsScreen(
                    subscriptionSettings = subscriptionSettings,
                    title = "Advanced Settings",
                    onAction = onAction,
                    onNavigateBack = {},
                    phoneNumberDialogState = phoneNumberDialogState,
                )
            }
        }
    }

    private fun createDefaultSubscription(
        subId: Int = 1,
        displayDetail: String = "+1234567890",
        phoneNumber: String = "+1234567890",
        defaultPhoneNumber: String = "+1234567890",
        isGroupMmsSupported: Boolean = false,
        isGroupMmsEnabled: Boolean = true,
        autoRetrieveMms: Boolean = true,
        autoRetrieveMmsWhenRoaming: Boolean = false,
        isDeliveryReportsSupported: Boolean = false,
        deliveryReportsEnabled: Boolean = false,
        isWirelessAlertsSupported: Boolean = false,
        isDefaultSmsApp: Boolean = true,
    ): SubscriptionUiState {
        return SubscriptionUiState(
            subId = SubId(subId),
            displayName = "SIM 1",
            displayDetail = displayDetail,
            phoneNumber = phoneNumber,
            defaultPhoneNumber = defaultPhoneNumber,
            isGroupMmsSupported = isGroupMmsSupported,
            isGroupMmsEnabled = isGroupMmsEnabled,
            autoRetrieveMms = autoRetrieveMms,
            autoRetrieveMmsWhenRoaming = autoRetrieveMmsWhenRoaming,
            isDeliveryReportsSupported = isDeliveryReportsSupported,
            deliveryReportsEnabled = deliveryReportsEnabled,
            isWirelessAlertsSupported = isWirelessAlertsSupported,
            isDefaultSmsApp = isDefaultSmsApp,
        )
    }
}
