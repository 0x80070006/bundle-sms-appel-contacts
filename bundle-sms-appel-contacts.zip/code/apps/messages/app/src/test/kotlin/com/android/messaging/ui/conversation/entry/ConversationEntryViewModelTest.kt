package com.android.messaging.ui.conversation.entry

import androidx.lifecycle.SavedStateHandle
import com.android.messaging.data.conversation.mapper.ConversationMessageDataDraftMapper
import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.data.conversation.model.MessageId
import com.android.messaging.data.conversation.model.ParticipantId
import com.android.messaging.data.conversation.model.draft.ConversationDraft
import com.android.messaging.datamodel.data.MessageData
import com.android.messaging.testutil.MainDispatcherRule
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import com.android.messaging.testutil.assertThat
import com.android.messaging.ui.conversation.entry.model.ConversationEntryLaunchRequest
import com.android.messaging.ui.conversation.entry.model.ConversationEntryStartupAttachment
import com.android.messaging.ui.conversation.entry.model.ConversationEntryUiState
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
internal class ConversationEntryViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    @Test
    fun launchRequest_setsConversationDraftScrollAndStartupAttachment() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val draftData = mockk<MessageData>()
            val mappedDraft = ConversationDraft(messageText = "Hello")
            val mapper = createMapper(draftData = draftData, mappedDraft = mappedDraft)
            val launchStore = ConversationLaunchStoreImpl()
            createViewModel(mapper = mapper, launchStore = launchStore).also { viewModel ->
                launchStore.submit(
                    request = ConversationEntryLaunchRequest(
                        conversationId = CONVERSATION_ID,
                        draftData = draftData,
                        startupAttachmentUri = "content://media/1",
                        startupAttachmentType = "image/png",
                        messageId = MessageId("12"),
                    ),
                )
                advanceUntilIdle()

                assertEquals(
                    ConversationEntryUiState(
                        conversationId = CONVERSATION_ID,
                        pendingDraft = mappedDraft,
                        pendingScrollMessageId = MessageId("12"),
                        pendingStartupAttachment = ConversationEntryStartupAttachment(
                            contentType = "image/png",
                            contentUri = "content://media/1",
                        ),
                    ),
                    viewModel.uiState.value,
                )
            }
            verify(exactly = 1) {
                mapper.map(messageData = draftData)
            }
        }
    }

    @Test
    fun launchRequest_appliesEveryRequestUnconditionally() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val draftData = mockk<MessageData>()
            val mapper = createMapper(
                draftData = draftData,
                mappedDraft = ConversationDraft(messageText = "First"),
            )
            val launchStore = ConversationLaunchStoreImpl()
            val viewModel = createViewModel(mapper = mapper, launchStore = launchStore)

            launchStore.submit(
                request = ConversationEntryLaunchRequest(
                    conversationId = CONVERSATION_ID,
                    draftData = draftData,
                ),
            )
            launchStore.submit(
                request = ConversationEntryLaunchRequest(
                    conversationId = ConversationId("conversation-2"),
                    draftData = draftData,
                ),
            )
            advanceUntilIdle()

            assertEquals(ConversationId("conversation-2"), viewModel.uiState.value.conversationId)
            verify(exactly = 2) {
                mapper.map(messageData = draftData)
            }
        }
    }

    @Test
    fun conversationNavigationRequest_setsConversationAndSelfParticipant() {
        val viewModel = createViewModel()

        viewModel.onConversationNavigationRequested(
            conversationId = CONVERSATION_ID,
            pendingSelfParticipantId = ParticipantId("self-1"),
        )

        assertEquals(CONVERSATION_ID, viewModel.uiState.value.conversationId)
        assertThat(viewModel.uiState.value.pendingSelfParticipantId).isEqualTo(
            ParticipantId("self-1"),
        )
    }

    @Test
    fun consumeCallbacks_clearOnlyMatchingPendingValues() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val launchStore = ConversationLaunchStoreImpl()
            val viewModel = createViewModel(launchStore = launchStore)
            launchStore.submit(
                request = ConversationEntryLaunchRequest(
                    conversationId = CONVERSATION_ID,
                    draftData = mockk(),
                    startupAttachmentUri = "content://media/1",
                    startupAttachmentType = "image/png",
                    messageId = MessageId("3"),
                ),
            )
            advanceUntilIdle()
            viewModel.onConversationNavigationRequested(
                conversationId = CONVERSATION_ID,
                pendingSelfParticipantId = ParticipantId("self-1"),
            )

            viewModel.onDraftPayloadConsumed(conversationId = ConversationId("other"))
            viewModel.onScrollMessageIdConsumed(conversationId = ConversationId("other"))
            viewModel.onStartupAttachmentConsumed(conversationId = ConversationId("other"))
            viewModel.onPendingSelfParticipantIdConsumed(conversationId = ConversationId("other"))

            assertEquals(
                ConversationDraft(messageText = "Mapped"),
                viewModel.uiState.value.pendingDraft,
            )
            assertEquals(MessageId("3"), viewModel.uiState.value.pendingScrollMessageId)
            assertThat(viewModel.uiState.value.pendingSelfParticipantId).isEqualTo(
                ParticipantId("self-1"),
            )
            assertEquals(
                ConversationEntryStartupAttachment(
                    contentType = "image/png",
                    contentUri = "content://media/1",
                ),
                viewModel.uiState.value.pendingStartupAttachment,
            )

            viewModel.onDraftPayloadConsumed(conversationId = CONVERSATION_ID)
            viewModel.onScrollMessageIdConsumed(conversationId = CONVERSATION_ID)
            viewModel.onStartupAttachmentConsumed(conversationId = CONVERSATION_ID)
            viewModel.onPendingSelfParticipantIdConsumed(conversationId = CONVERSATION_ID)

            assertNull(viewModel.uiState.value.pendingDraft)
            assertNull(viewModel.uiState.value.pendingScrollMessageId)
            assertNull(viewModel.uiState.value.pendingSelfParticipantId)
            assertNull(viewModel.uiState.value.pendingStartupAttachment)
        }
    }

    @Test
    fun launchPayload_survivesRecreationAndIsNotReseededByAFreshStore() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val draftData = mockk<MessageData>()
            val mappedDraft = ConversationDraft(messageText = "Restored")
            val mapper = createMapper(draftData = draftData, mappedDraft = mappedDraft)
            val savedStateHandle = SavedStateHandle()

            val launchStore = ConversationLaunchStoreImpl()
            createViewModel(
                mapper = mapper,
                savedStateHandle = savedStateHandle,
                launchStore = launchStore,
            )
            launchStore.submit(
                request = ConversationEntryLaunchRequest(
                    conversationId = CONVERSATION_ID,
                    draftData = draftData,
                    startupAttachmentUri = "content://media/1",
                    startupAttachmentType = "image/png",
                    messageId = MessageId("12"),
                ),
            )
            advanceUntilIdle()

            val recreatedViewModel = createViewModel(
                mapper = mapper,
                savedStateHandle = savedStateHandle,
                launchStore = ConversationLaunchStoreImpl(),
            )
            advanceUntilIdle()

            assertEquals(
                ConversationEntryUiState(
                    conversationId = CONVERSATION_ID,
                    pendingDraft = mappedDraft,
                    pendingScrollMessageId = MessageId("12"),
                    pendingStartupAttachment = ConversationEntryStartupAttachment(
                        contentType = "image/png",
                        contentUri = "content://media/1",
                    ),
                ),
                recreatedViewModel.uiState.value,
            )
        }
    }

    @Test
    fun conversationNavigationState_survivesViewModelRecreationViaSavedStateHandle() {
        val savedStateHandle = SavedStateHandle()

        createViewModel(savedStateHandle = savedStateHandle).onConversationNavigationRequested(
            conversationId = CONVERSATION_ID,
            pendingSelfParticipantId = ParticipantId("self-1"),
        )

        val recreatedViewModel = createViewModel(savedStateHandle = savedStateHandle)

        assertEquals(CONVERSATION_ID, recreatedViewModel.uiState.value.conversationId)
        assertThat(recreatedViewModel.uiState.value.pendingSelfParticipantId).isEqualTo(
            ParticipantId("self-1"),
        )
    }

    private fun createViewModel(
        mapper: ConversationMessageDataDraftMapper = createMapper(),
        savedStateHandle: SavedStateHandle = SavedStateHandle(),
        launchStore: ConversationLaunchStore = ConversationLaunchStoreImpl(),
    ): ConversationEntryViewModel {
        return ConversationEntryViewModel(
            conversationMessageDataDraftMapper = mapper,
            savedStateHandle = savedStateHandle,
            launchStore = launchStore,
        )
    }

    private fun createMapper(
        draftData: MessageData? = null,
        mappedDraft: ConversationDraft = ConversationDraft(messageText = "Mapped"),
    ): ConversationMessageDataDraftMapper {
        val mapper = mockk<ConversationMessageDataDraftMapper>()
        every {
            mapper.map(messageData = any())
        } returns mappedDraft
        if (draftData != null) {
            every {
                mapper.map(messageData = draftData)
            } returns mappedDraft
        }
        return mapper
    }
}
