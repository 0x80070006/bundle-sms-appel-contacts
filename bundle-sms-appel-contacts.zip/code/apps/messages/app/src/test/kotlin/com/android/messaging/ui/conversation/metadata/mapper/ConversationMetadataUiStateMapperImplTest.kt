package com.android.messaging.ui.conversation.metadata.mapper

import com.android.messaging.data.conversation.model.ParticipantId
import com.android.messaging.data.conversation.model.metadata.ConversationComposerAvailability
import com.android.messaging.data.conversation.model.metadata.ConversationMetadata
import com.android.messaging.testutil.TEST_CALL_ACTION_PHONE_NUMBER
import com.android.messaging.testutil.assertThat
import com.android.messaging.ui.conversation.metadata.model.ConversationMetadataUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ConversationMetadataUiStateMapperImplTest {

    private val mapper = ConversationMetadataUiStateMapperImpl()

    @Test
    fun map_snoozedOneOnOneConversation_usesSingleAvatarDisplayDestinationAndSnooze() {
        val result = mapper.map(
            metadata = ConversationMetadata(
                conversationName = "Carol",
                selfParticipantId = ParticipantId("self-1"),
                isGroupConversation = false,
                includeEmailAddress = false,
                participantCount = 1,
                otherParticipantDisplayDestination = "(555) 123-4567",
                otherParticipantNormalizedDestination = TEST_CALL_ACTION_PHONE_NUMBER,
                otherParticipantContactLookupKey = "lookup-key",
                otherParticipantPhotoUri = "content://contacts/people/1/photo",
                isArchived = false,
                isBlocked = false,
                isSnoozed = true,
                composerAvailability = ConversationComposerAvailability.Editable,
                sortTimestamp = 0L,
            ),
        )

        assertThat(result).isEqualTo(
            ConversationMetadataUiState.Present(
                title = "Carol",
                avatar = ConversationMetadataUiState.Avatar.Single(
                    photoUri = "content://contacts/people/1/photo",
                    normalizedDestination = TEST_CALL_ACTION_PHONE_NUMBER,
                    displayName = "Carol",
                ),
                participantCount = 1,
                otherParticipantDisplayDestination = "(555) 123-4567",
                otherParticipantPhoneNumber = TEST_CALL_ACTION_PHONE_NUMBER,
                otherParticipantContactLookupKey = "lookup-key",
                isArchived = false,
                isBlocked = false,
                composerAvailability = ConversationComposerAvailability.Editable,
                isSnoozed = true,
            )
        )
    }

    @Test
    fun map_groupConversation_usesGroupAvatarAndNoPhoneNumber() {
        val result = mapper.map(
            metadata = ConversationMetadata(
                conversationName = "Weekend plan",
                selfParticipantId = ParticipantId("self-1"),
                isGroupConversation = true,
                includeEmailAddress = false,
                participantCount = 3,
                otherParticipantDisplayDestination = null,
                otherParticipantNormalizedDestination = "not-a-phone-number",
                otherParticipantContactLookupKey = null,
                otherParticipantPhotoUri = "content://contacts/people/1/photo",
                isArchived = true,
                isBlocked = false,
                isSnoozed = false,
                composerAvailability = ConversationComposerAvailability.Editable,
                sortTimestamp = 0L,
            ),
        )

        val presentState = result as ConversationMetadataUiState.Present
        assertEquals(ConversationMetadataUiState.Avatar.Group, presentState.avatar)
        assertNull(presentState.otherParticipantPhoneNumber)
        assertEquals(true, presentState.isArchived)
    }
}
