package com.android.messaging.ui.conversation.focus.delegate

import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.datamodel.BugleNotifications
import com.android.messaging.datamodel.DataModel
import com.android.messaging.testutil.MainDispatcherRule
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.runs
import io.mockk.unmockkStatic
import io.mockk.verify
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
class ConversationFocusDelegateImplTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var dataModel: DataModel
    private var focusedConversationId: String? = null

    @Before
    fun setUp() {
        dataModel = mockk(relaxed = true)
        every { dataModel.setFocusedConversation(any()) } answers {
            focusedConversationId = firstArg()
        }
        every { dataModel.isFocusedConversation(any()) } answers {
            focusedConversationId != null && focusedConversationId == firstArg<String?>()
        }
        mockkStatic(DataModel::class)
        every { DataModel.get() } returns dataModel
        mockkStatic(BugleNotifications::class)
        every {
            BugleNotifications.markMessagesAsRead(any(), any())
        } just runs
    }

    @After
    fun tearDown() {
        unmockkStatic(DataModel::class)
        unmockkStatic(BugleNotifications::class)
    }

    @Test
    fun setScreenFocused_withConversationId_setsFocusAndMarksRead() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()

            verify(exactly = 1) {
                dataModel.setFocusedConversation(CONVERSATION_ID.value)
            }
            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead(
                    CONVERSATION_ID.value,
                    true,
                )
            }
        }
    }

    @Test
    fun setScreenFocused_withCancelNotificationFalse_propagatesFlag() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true, cancelNotification = false)
            runCurrent()

            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead(
                    CONVERSATION_ID.value,
                    false,
                )
            }
        }
    }

    @Test
    fun setScreenFocused_withNullConversationId_doesNotMarkRead() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = null)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()

            verify(exactly = 0) {
                BugleNotifications.markMessagesAsRead(any(), any())
            }
            verify(exactly = 0) {
                dataModel.setFocusedConversation(ofType<String>())
            }
        }
    }

    @Test
    fun setScreenFocused_withBlankConversationId_doesNotMarkRead() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(
                value = ConversationId("   "),
            )
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()

            verify(exactly = 0) {
                BugleNotifications.markMessagesAsRead(any(), any())
            }
        }
    }

    @Test
    fun setScreenFocused_unfocused_clearsFocusedConversation() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()
            assertEquals(CONVERSATION_ID.value, focusedConversationId)
            delegate.setScreenFocused(focused = false)
            runCurrent()

            assertNull(focusedConversationId)
        }
    }

    @Test
    fun setScreenFocused_unfocusedAfterScopeIsCancelled_clearsFocusedConversation() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val scope = CoroutineScope(context = Job())
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(
                conversationIdFlow = conversationIdFlow,
                scope = scope,
            )

            delegate.setScreenFocused(focused = true)
            runCurrent()
            // ViewModel.clear() cancels viewModelScope before onCleared() unfocuses.
            scope.cancel()
            delegate.setScreenFocused(focused = false)
            runCurrent()

            assertNull(focusedConversationId)
        }
    }

    @Test
    fun setScreenFocused_unfocusedAfterAnotherConversationTookFocus_keepsThatFocus() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()
            dataModel.setFocusedConversation("conversation-2")
            delegate.setScreenFocused(focused = false)
            runCurrent()

            assertEquals("conversation-2", focusedConversationId)
        }
    }

    @Test
    fun conversationIdSwap_whileFocused_marksReadForNewConversation() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()
            conversationIdFlow.value = ConversationId("conversation-2")
            runCurrent()

            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead(CONVERSATION_ID.value, true)
            }
            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead("conversation-2", true)
            }
            verify(exactly = 1) {
                dataModel.setFocusedConversation("conversation-2")
            }
        }
    }

    @Test
    fun setScreenFocused_repeatedIdenticalFocusedRequests_marksReadOnce() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)

            delegate.setScreenFocused(focused = true)
            delegate.setScreenFocused(focused = true)
            delegate.setScreenFocused(focused = true)
            runCurrent()

            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead(CONVERSATION_ID.value, true)
            }
        }
    }

    @Test
    fun bind_calledTwice_onlyBindsFirstScope() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val conversationIdFlow = MutableStateFlow<ConversationId?>(value = CONVERSATION_ID)
            val secondConversationIdFlow = MutableStateFlow<ConversationId?>(
                value = ConversationId("conversation-rebound"),
            )
            val delegate = createBoundDelegate(conversationIdFlow = conversationIdFlow)
            delegate.bind(scope = backgroundScope, conversationIdFlow = secondConversationIdFlow)

            delegate.setScreenFocused(focused = true)
            runCurrent()

            verify(exactly = 1) {
                BugleNotifications.markMessagesAsRead(CONVERSATION_ID.value, true)
            }
            verify(exactly = 0) {
                BugleNotifications.markMessagesAsRead("conversation-rebound", any())
            }
        }
    }

    private fun TestScope.createBoundDelegate(
        conversationIdFlow: MutableStateFlow<ConversationId?>,
        scope: CoroutineScope = backgroundScope,
    ): ConversationFocusDelegateImpl {
        val delegate = ConversationFocusDelegateImpl(
            mainDispatcher = mainDispatcherRule.testDispatcher,
        )
        delegate.bind(scope = scope, conversationIdFlow = conversationIdFlow)
        runCurrent()
        return delegate
    }
}
