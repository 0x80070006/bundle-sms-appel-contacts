package com.android.messaging.data.conversation.repository.conversations

import android.database.ContentObserver
import android.database.Cursor
import app.cash.turbine.test
import com.android.messaging.datamodel.DatabaseHelper.ConversationColumns
import com.android.messaging.datamodel.DatabaseHelper.MessageColumns
import com.android.messaging.datamodel.DatabaseHelper.ParticipantColumns
import com.android.messaging.datamodel.MessagingContentProvider
import com.android.messaging.datamodel.data.ConversationMessageData
import com.android.messaging.datamodel.data.MessageData
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.runs
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
internal class ConversationsRepositoryMessagesTest : BaseConversationsRepositoryTest() {

    @Test
    fun getConversationMessages_registersAndUnregistersObserverForCollection() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = emptyList()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                assertTrue(awaitItem().messages.isEmpty())
                cancelAndIgnoreRemainingEvents()
            }

            verify(exactly = 1) {
                contentResolver.registerContentObserver(
                    expectedUri,
                    true,
                    registeredObservers.single(),
                )
            }
            verify(exactly = 1) {
                contentResolver.unregisterContentObserver(registeredObservers.single())
            }
            assertEquals(
                ConversationMessageData.getProjection().toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMessages_emitsMessagesInUiOrderWithLegacyClusteringRules() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val messagesInUiOrder = listOf(
                messageRow(
                    messageId = "pair-1",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 0L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "Pair top",
                ),
                messageRow(
                    messageId = "pair-2",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 30_000L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "Pair bottom",
                ),
                messageRow(
                    messageId = "gap-break",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 91_000L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "Gap break",
                ),
                messageRow(
                    messageId = "sender-break",
                    participantId = "participant-b",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 100_000L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "Different sender",
                ),
                messageRow(
                    messageId = "outgoing-1",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 130_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_COMPLETE,
                    text = "Outgoing top",
                ),
                messageRow(
                    messageId = "outgoing-2",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 150_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_COMPLETE,
                    text = "Outgoing bottom",
                ),
                messageRow(
                    messageId = "self-break",
                    participantId = "self-sender",
                    selfParticipantId = "self-2",
                    receivedTimestamp = 170_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_COMPLETE,
                    text = "Different self participant",
                ),
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = messagesInUiOrder.asReversed()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(
                    messagesInUiOrder.map { it.messageId },
                    messages.map { it.messageId },
                )
                assertEquals(
                    messagesInUiOrder.map { it.text },
                    messages.map { it.text },
                )

                assertClusterState(
                    message = messages[0],
                    canClusterWithPrevious = false,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[1],
                    canClusterWithPrevious = true,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[2],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[3],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[4],
                    canClusterWithPrevious = false,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[5],
                    canClusterWithPrevious = true,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[6],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )

                cancelAndIgnoreRemainingEvents()
            }

            verify(exactly = 1) { contentResolver.query(expectedQueryUri, any(), null, null, null) }
            assertEquals(
                ConversationMessageData.getProjection().toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMessages_requeriesWhenObserverChanges() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val firstMessage = messageRow(
                messageId = "first",
                participantId = "participant-a",
                selfParticipantId = "self-1",
                receivedTimestamp = 1_000L,
                status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                text = "First",
            )
            val secondMessage = messageRow(
                messageId = "second",
                participantId = "participant-a",
                selfParticipantId = "self-1",
                receivedTimestamp = 2_000L,
                status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                text = "Second",
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            every {
                contentResolver.query(
                    expectedQueryUri,
                    any(),
                    null,
                    null,
                    null,
                )
            } answers {
                capturedProjections.add(secondArg<Array<String>?>())
                when (capturedProjections.size) {
                    1 -> createConversationMessagesCursor(rows = listOf(firstMessage))
                    2 -> createConversationMessagesCursor(
                        rows = listOf(secondMessage, firstMessage),
                    )
                    else -> error("Unexpected query call ${capturedProjections.size}")
                }
            }

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                assertEquals(listOf("first"), awaitItem().messages.map { it.messageId })

                registeredObservers.single().onChange(false)

                assertEquals(
                    listOf("first", "second"),
                    awaitItem().messages.map { it.messageId },
                )

                cancelAndIgnoreRemainingEvents()
            }

            verify(exactly = 2) {
                contentResolver.query(
                    expectedQueryUri,
                    any(),
                    null,
                    null,
                    null,
                )
            }
            assertEquals(
                listOf(
                    ConversationMessageData.getProjection().toList(),
                    ConversationMessageData.getProjection().toList(),
                ),
                capturedProjections.map { it?.toList() },
            )
        }
    }

    @Test
    fun getConversationMessages_singleMessageHasNoClustering() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val singleMessage = messageRow(
                messageId = "only",
                participantId = "participant-a",
                selfParticipantId = "self-1",
                receivedTimestamp = 1_000L,
                status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                text = "Only message",
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = listOf(singleMessage)),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(1, messages.size)
                assertEquals("only", messages[0].messageId)
                assertClusterState(
                    message = messages[0],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_clustersAtExactlyOneMinuteButNotOneMillisOver() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val messagesInUiOrder = listOf(
                messageRow(
                    messageId = "msg-a",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 0L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "First",
                ),
                messageRow(
                    messageId = "msg-b",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 60_000L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "Exactly one minute later",
                ),
                messageRow(
                    messageId = "msg-c",
                    participantId = "participant-a",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 120_001L,
                    status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                    text = "One millisecond over one minute from msg-b",
                ),
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = messagesInUiOrder.asReversed()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(3, messages.size)

                assertClusterState(
                    message = messages[0],
                    canClusterWithPrevious = false,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[1],
                    canClusterWithPrevious = true,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[2],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_doesNotClusterFailedMessageWithDeliveredNeighbours() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val messagesInUiOrder = listOf(
                messageRow(
                    messageId = "delivered-before",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 0L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_DELIVERED,
                    text = "This one went through fine",
                ),
                messageRow(
                    messageId = "failed",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 10_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_FAILED,
                    text = "This one did not go through",
                ),
                messageRow(
                    messageId = "delivered-after",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 20_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_DELIVERED,
                    text = "This one went through fine too",
                ),
                messageRow(
                    messageId = "delivered-last",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 30_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_DELIVERED,
                    text = "And so did this one",
                ),
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = messagesInUiOrder.asReversed()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(
                    messagesInUiOrder.map { it.messageId },
                    messages.map { it.messageId },
                )

                // The failed message must never hide behind a neighbour's metadata line: it is
                // the only place the failure is shown, and the only way to reach "tap to retry".
                assertClusterState(
                    message = messages[0],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )
                assertClusterState(
                    message = messages[1],
                    canClusterWithPrevious = false,
                    canClusterWithNext = false,
                )
                // Delivered neighbours on the far side of the failure still cluster together.
                assertClusterState(
                    message = messages[2],
                    canClusterWithPrevious = false,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[3],
                    canClusterWithPrevious = true,
                    canClusterWithNext = false,
                )

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_doesNotClusterConsecutiveFailedMessages() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val messagesInUiOrder = listOf(
                messageRow(
                    messageId = "failed-1",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 0L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_FAILED,
                    text = "First failure",
                ),
                messageRow(
                    messageId = "failed-2",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 10_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_FAILED,
                    text = "Second failure",
                ),
                messageRow(
                    messageId = "failed-3",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 20_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_FAILED,
                    text = "Third failure",
                ),
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = messagesInUiOrder.asReversed()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(3, messages.size)

                // A run of failures shares one status line otherwise, leaving all but the last
                // failure unmarked.
                messages.forEach { message ->
                    assertClusterState(
                        message = message,
                        canClusterWithPrevious = false,
                        canClusterWithNext = false,
                    )
                }

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_stillClustersOutgoingMessagesWithDifferentSuccessStatuses() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )
            val messagesInUiOrder = listOf(
                messageRow(
                    messageId = "complete",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 0L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_COMPLETE,
                    text = "Sent, no delivery report yet",
                ),
                messageRow(
                    messageId = "delivered",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 10_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_DELIVERED,
                    text = "This one got its delivery report",
                ),
                messageRow(
                    messageId = "sending",
                    participantId = "self-sender",
                    selfParticipantId = "self-1",
                    receivedTimestamp = 20_000L,
                    status = MessageData.BUGLE_STATUS_OUTGOING_SENDING,
                    text = "Still in flight",
                ),
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = messagesInUiOrder.asReversed()),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                val messages = awaitItem().messages

                assertEquals(3, messages.size)

                // Only failures break a cluster. Delivery reports land one message at a time and
                // in-flight messages settle through several statuses, so a successful run is
                // routinely a mix of them -- splitting on status alone would tear apart ordinary
                // threads and make every arriving report re-flow the list.
                assertClusterState(
                    message = messages[0],
                    canClusterWithPrevious = false,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[1],
                    canClusterWithPrevious = true,
                    canClusterWithNext = true,
                )
                assertClusterState(
                    message = messages[2],
                    canClusterWithPrevious = true,
                    canClusterWithNext = false,
                )

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_returnsEmptyListWhenQueryReturnsNull() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                TEST_WINDOW_SIZE + 1,
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = null,
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(TEST_WINDOW_SIZE),
            ).test {
                assertTrue(awaitItem().messages.isEmpty())
                cancelAndIgnoreRemainingEvents()
            }

            assertEquals(
                ConversationMessageData.getProjection().toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMessages_reportsMoreWhenTheWindowIsFull() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                WINDOW_SIZE_OF_TWO + 1,
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(
                    rows = listOf(
                        messageRow(
                            messageId = "newest",
                            participantId = "participant-a",
                            selfParticipantId = "self-1",
                            receivedTimestamp = 2_000L,
                            status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                            text = "Newest",
                        ),
                        messageRow(
                            messageId = "older",
                            participantId = "participant-a",
                            selfParticipantId = "self-1",
                            receivedTimestamp = 1_000L,
                            status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                            text = "Older",
                        ),
                        messageRow(
                            messageId = "oldest",
                            participantId = "participant-a",
                            selfParticipantId = "self-1",
                            receivedTimestamp = 500L,
                            status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                            text = "Oldest",
                        ),
                    ),
                ),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(WINDOW_SIZE_OF_TWO),
            ).test {
                val window = awaitItem()

                assertTrue(window.hasMore)
                assertEquals(
                    listOf("older", "newest"),
                    window.messages.map { it.messageId },
                )
                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_reportsNoMoreWhenTheWindowIsNotFull() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val expectedQueryUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
                WINDOW_SIZE_OF_TWO + 1,
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedQueryUri,
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(
                    rows = listOf(
                        messageRow(
                            messageId = "newest",
                            participantId = "participant-a",
                            selfParticipantId = "self-1",
                            receivedTimestamp = 2_000L,
                            status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                            text = "Newest",
                        ),
                        messageRow(
                            messageId = "older",
                            participantId = "participant-a",
                            selfParticipantId = "self-1",
                            receivedTimestamp = 1_000L,
                            status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                            text = "Older",
                        ),
                    ),
                ),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = flowOf(WINDOW_SIZE_OF_TWO),
            ).test {
                assertEquals(false, awaitItem().hasMore)
                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_requeriesWithTheLargerWindowWhenItGrows() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                CONVERSATION_ID.value,
            )
            val newestMessage = messageRow(
                messageId = "newest",
                participantId = "participant-a",
                selfParticipantId = "self-1",
                receivedTimestamp = 2_000L,
                status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                text = "Newest",
            )
            val olderMessage = messageRow(
                messageId = "older",
                participantId = "participant-a",
                selfParticipantId = "self-1",
                receivedTimestamp = 1_000L,
                status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                text = "Older",
            )
            val windowSizes = MutableStateFlow(value = 1)

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                    CONVERSATION_ID.value,
                    2,
                ),
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(rows = listOf(newestMessage)),
            )
            stubQuery(
                expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                    CONVERSATION_ID.value,
                    WINDOW_SIZE_OF_TWO + 1,
                ),
                capturedProjections = capturedProjections,
                result = createConversationMessagesCursor(
                    rows = listOf(newestMessage, olderMessage),
                ),
            )

            repository.getConversationMessages(
                conversationId = CONVERSATION_ID,
                windowSizes = windowSizes,
            ).test {
                assertEquals(listOf("newest"), awaitItem().messages.map { it.messageId })

                windowSizes.value = WINDOW_SIZE_OF_TWO

                // The query is newest first and the repository walks the cursor backwards, so the
                // window reaches the ui oldest first.
                assertEquals(
                    listOf("older", "newest"),
                    awaitItem().messages.map { it.messageId },
                )
                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMessages_whenTheCollectorLeavesMidWalk_stopsWalkingTheCursor() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val repository = createRepository()
            var cursorMoves = 0
            var collection: Job? = null
            val cursor = createConversationMessagesCursor(
                rows = List(ROW_COUNT) { index ->
                    messageRow(
                        messageId = "message-$index",
                        participantId = "participant-1",
                        selfParticipantId = "self-1",
                        receivedTimestamp = index.toLong(),
                        status = MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                        text = "message $index",
                    )
                },
                onCursorMove = {
                    cursorMoves += 1
                    if (cursorMoves == CANCEL_AFTER_CURSOR_MOVES) {
                        collection?.cancel()
                    }
                },
            )

            stubObserverRegistration(
                registeredObservers = mutableListOf(),
                expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                    CONVERSATION_ID.value,
                ),
            )
            stubQuery(
                expectedUri = MessagingContentProvider.buildConversationMessagesUri(
                    CONVERSATION_ID.value,
                    TEST_WINDOW_SIZE + 1,
                ),
                capturedProjections = mutableListOf(),
                result = cursor,
            )

            collection = backgroundScope.launch {
                repository.getConversationMessages(
                    conversationId = CONVERSATION_ID,
                    windowSizes = flowOf(TEST_WINDOW_SIZE),
                ).collect { }
            }
            runCurrent()

            assertTrue(
                "kept walking after the screen left: $cursorMoves moves for $ROW_COUNT rows",
                cursorMoves < ROW_COUNT,
            )
        }
    }

    private fun createConversationMessagesCursor(
        rows: List<TestMessageRow>,
        onCursorMove: () -> Unit = {},
    ): Cursor {
        val projection = ConversationMessageData.getProjection()
        val rowsByColumn = rows.map { it.toColumnValues() }
        var position = -1
        val cursor = mockk<Cursor>()

        fun currentRow(): Map<String, Any?> {
            check(position in rowsByColumn.indices) {
                "Cursor position $position is out of bounds for ${rowsByColumn.size} rows"
            }
            return rowsByColumn[position]
        }

        fun moveToPosition(positionToMove: Int): Boolean {
            return when {
                rowsByColumn.isEmpty() -> {
                    position = -1
                    false
                }

                positionToMove < 0 -> {
                    position = -1
                    false
                }

                positionToMove >= rowsByColumn.size -> {
                    position = rowsByColumn.size
                    false
                }

                else -> {
                    position = positionToMove
                    onCursorMove()
                    true
                }
            }
        }

        every { cursor.count } returns rowsByColumn.size
        every { cursor.close() } just runs
        every { cursor.position } answers { position }
        every { cursor.isBeforeFirst } answers {
            rowsByColumn.isNotEmpty() && position < 0
        }
        every { cursor.isAfterLast } answers {
            rowsByColumn.isNotEmpty() && position >= rowsByColumn.size
        }
        every { cursor.isFirst } answers {
            rowsByColumn.isNotEmpty() && position == 0
        }
        every { cursor.isLast } answers {
            rowsByColumn.isNotEmpty() && position == rowsByColumn.lastIndex
        }
        every { cursor.moveToPosition(any()) } answers {
            moveToPosition(positionToMove = firstArg())
        }
        every { cursor.move(any()) } answers {
            moveToPosition(positionToMove = position + firstArg<Int>())
        }
        every { cursor.moveToFirst() } answers {
            moveToPosition(positionToMove = 0)
        }
        every { cursor.moveToLast() } answers {
            moveToPosition(positionToMove = rowsByColumn.lastIndex)
        }
        every { cursor.moveToNext() } answers {
            val nextPosition = if (position < 0) 0 else position + 1
            moveToPosition(positionToMove = nextPosition)
        }
        every { cursor.moveToPrevious() } answers {
            val previousPosition = if (position > rowsByColumn.lastIndex) {
                rowsByColumn.lastIndex
            } else {
                position - 1
            }
            moveToPosition(positionToMove = previousPosition)
        }
        every { cursor.getString(any()) } answers {
            currentRow()[projection[firstArg<Int>()]]?.toString()
        }
        every { cursor.getInt(any()) } answers {
            currentRow()[projection[firstArg<Int>()]].toIntValue()
        }
        every { cursor.getLong(any()) } answers {
            currentRow()[projection[firstArg<Int>()]].toLongValue()
        }

        return cursor
    }

    private fun assertClusterState(
        message: ConversationMessageData,
        canClusterWithPrevious: Boolean,
        canClusterWithNext: Boolean,
    ) {
        assertEquals(canClusterWithPrevious, message.canClusterWithPreviousMessage)
        assertEquals(canClusterWithNext, message.canClusterWithNextMessage)
    }

    private fun messageRow(
        messageId: String,
        participantId: String,
        selfParticipantId: String,
        receivedTimestamp: Long,
        status: Int,
        text: String,
    ): TestMessageRow {
        return TestMessageRow(
            messageId = messageId,
            participantId = participantId,
            selfParticipantId = selfParticipantId,
            receivedTimestamp = receivedTimestamp,
            status = status,
            text = text,
        )
    }

    private data class TestMessageRow(
        val messageId: String,
        val participantId: String,
        val selfParticipantId: String,
        val receivedTimestamp: Long,
        val status: Int,
        val text: String,
    ) {
        fun toColumnValues(): Map<String, Any?> {
            return mapOf(
                MessageColumns._ID to messageId,
                MessageColumns.CONVERSATION_ID to CONVERSATION_ID,
                MessageColumns.SENDER_PARTICIPANT_ID to participantId,
                ConversationColumns.ICON to "",
                "parts_ids" to "part-$messageId",
                "parts_content_types" to TEXT_CONTENT_TYPE,
                "parts_content_uris" to "",
                "parts_widths" to "0",
                "parts_heights" to "0",
                "parts_texts" to text,
                "parts_count" to 1,
                MessageColumns.SENT_TIMESTAMP to receivedTimestamp,
                MessageColumns.RECEIVED_TIMESTAMP to receivedTimestamp,
                MessageColumns.SEEN to 1,
                MessageColumns.READ to 1,
                MessageColumns.PROTOCOL to MessageData.PROTOCOL_SMS,
                MessageColumns.STATUS to status,
                MessageColumns.SMS_MESSAGE_URI to "",
                MessageColumns.SMS_PRIORITY to 0,
                MessageColumns.SMS_MESSAGE_SIZE to 0,
                MessageColumns.MMS_SUBJECT to "",
                MessageColumns.MMS_EXPIRY to 0L,
                MessageColumns.RAW_TELEPHONY_STATUS to 0,
                MessageColumns.SELF_PARTICIPANT_ID to selfParticipantId,
                ParticipantColumns.FULL_NAME to "Sender $participantId",
                ParticipantColumns.FIRST_NAME to "Sender",
                ParticipantColumns.DISPLAY_DESTINATION to "+1555$messageId",
                ParticipantColumns.NORMALIZED_DESTINATION to "+1555$messageId",
                ParticipantColumns.PROFILE_PHOTO_URI to "",
                ParticipantColumns.CONTACT_ID to 0L,
                ParticipantColumns.LOOKUP_KEY to "",
            )
        }
    }

    private fun Any?.toIntValue(): Int {
        return when (this) {
            null -> 0
            is Int -> this
            is Long -> this.toInt()
            is Boolean -> if (this) 1 else 0
            is String -> this.toInt()
            else -> error("Unsupported int value: $this")
        }
    }

    private fun Any?.toLongValue(): Long {
        return when (this) {
            null -> 0L
            is Long -> this
            is Int -> this.toLong()
            is Boolean -> if (this) 1L else 0L
            is String -> this.toLong()
            else -> error("Unsupported long value: $this")
        }
    }

    private companion object {
        private const val TEXT_CONTENT_TYPE = "text/plain"
        private const val TEST_WINDOW_SIZE = 500
        private const val WINDOW_SIZE_OF_TWO = 2
        private const val ROW_COUNT = 10
        private const val CANCEL_AFTER_CURSOR_MOVES = 2
    }
}
