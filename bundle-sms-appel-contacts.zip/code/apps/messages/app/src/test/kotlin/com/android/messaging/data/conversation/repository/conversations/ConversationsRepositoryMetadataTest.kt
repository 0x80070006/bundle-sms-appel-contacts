package com.android.messaging.data.conversation.repository.conversations

import android.database.ContentObserver
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import app.cash.turbine.test
import com.android.messaging.data.conversation.model.ParticipantId
import com.android.messaging.data.conversation.model.metadata.ConversationComposerAvailability
import com.android.messaging.data.conversation.model.metadata.ConversationComposerDisabledReason
import com.android.messaging.datamodel.DatabaseHelper.ConversationColumns
import com.android.messaging.datamodel.DatabaseHelper.MessageColumns
import com.android.messaging.datamodel.MessagingContentProvider
import com.android.messaging.datamodel.data.ConversationListItemData
import com.android.messaging.datamodel.data.MessageData
import com.android.messaging.datamodel.data.ParticipantData
import com.android.messaging.sms.MmsConfig
import com.android.messaging.testutil.TEST_CALL_ACTION_PHONE_NUMBER
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import com.android.messaging.testutil.assertThat
import com.android.messaging.testutil.createParticipantsCursor
import com.android.messaging.testutil.participantRow
import com.android.messaging.testutil.stubActiveSubscriptions
import com.android.messaging.testutil.stubMmsConfig
import com.android.messaging.util.PhoneUtils
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
internal class ConversationsRepositoryMetadataTest : BaseConversationsRepositoryTest() {

    @Before
    fun setUpSubscriptions() {
        mockkStatic(MmsConfig::class, PhoneUtils::class)
        stubActiveSubscriptions(subIds = listOf(SUB_ID))
        stubMmsConfig(subId = SUB_ID, aliasEnabled = false)
    }

    @After
    fun tearDownSubscriptions() {
        unmockkStatic(MmsConfig::class, PhoneUtils::class)
    }

    @Test
    fun getConversationMetadata_registersAndUnregistersObserverForCollection() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedUri,
                capturedProjections = capturedProjections,
                result = createConversationMetadataCursor(
                    row = conversationMetadataRow(
                        conversationName = "Weekend plan",
                        selfParticipantId = "self-1",
                        participantCount = 3,
                    ),
                ),
            )

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                assertEquals("Weekend plan", awaitItem()?.conversationName)
                cancelAndIgnoreRemainingEvents()
            }

            verify(exactly = 1) {
                contentResolver.registerContentObserver(
                    expectedUri,
                    true,
                    registeredObservers.single(),
                )
            }
            verify(exactly = 1) {
                contentResolver.unregisterContentObserver(registeredObservers.single())
            }
            assertEquals(
                ConversationListItemData.PROJECTION.toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMetadata_emitsMappedMetadata() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedUri,
                capturedProjections = capturedProjections,
                result = createConversationMetadataCursor(
                    row = conversationMetadataRow(
                        conversationName = "Carol, Dave, Erin",
                        selfParticipantId = "self-2",
                        participantCount = 3,
                    ),
                ),
            )

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                val metadata = awaitItem()

                assertEquals("Carol, Dave, Erin", metadata?.conversationName)
                assertThat(metadata?.selfParticipantId).isEqualTo(ParticipantId("self-2"))
                assertEquals(true, metadata?.isGroupConversation)
                assertEquals(3, metadata?.participantCount)
                assertEquals(false, metadata?.isArchived)
                assertEquals(null, metadata?.otherParticipantContactLookupKey)

                cancelAndIgnoreRemainingEvents()
            }

            assertEquals(
                ConversationListItemData.PROJECTION.toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMetadata_exposesArchiveStatusAndLookupKey() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedUri,
                capturedProjections = capturedProjections,
                result = createConversationMetadataCursor(
                    row = conversationMetadataRow(
                        conversationName = "Carol",
                        selfParticipantId = "self-2",
                        participantCount = 2,
                        isArchived = true,
                        otherParticipantLookupKey = "lookup-key-carol",
                    ),
                ),
            )

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                val metadata = awaitItem()

                assertEquals(true, metadata?.isArchived)
                assertEquals("lookup-key-carol", metadata?.otherParticipantContactLookupKey)

                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMetadata_oneOnOneConversation_usesParticipantDetailsForSubtitleAndAvatar() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val metadataProjections = mutableListOf<Array<String>?>()
            val participantsProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val metadataUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )
            val participantsUri = MessagingContentProvider
                .buildConversationParticipantsUri(CONVERSATION_ID.value)

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = metadataUri,
            )
            stubQuery(
                expectedUri = metadataUri,
                capturedProjections = metadataProjections,
                result = createConversationMetadataCursor(
                    row = conversationMetadataRow(
                        conversationName = "Carol",
                        selfParticipantId = "self-2",
                        participantCount = 1,
                        otherParticipantLookupKey = "legacy-lookup-key",
                        otherParticipantNormalizedDestination = TEST_CALL_ACTION_PHONE_NUMBER,
                    ),
                ),
            )
            stubQuery(
                expectedUri = participantsUri,
                capturedProjections = participantsProjections,
                result = createParticipantsCursor(
                    participantRow(
                        participantId = "self-2",
                        subId = 1,
                        displayDestination = "",
                        normalizedDestination = "",
                        profilePhotoUri = "",
                        lookupKey = "",
                        contactId = 1L,
                        fullName = "Name self-2",
                        firstName = "Name",
                    ),
                    participantRow(
                        participantId = "participant-1",
                        subId = ParticipantData.OTHER_THAN_SELF_SUB_ID,
                        displayDestination = "(555) 123-4567",
                        normalizedDestination = TEST_CALL_ACTION_PHONE_NUMBER,
                        profilePhotoUri = "content://contacts/people/1/photo",
                        lookupKey = "lookup-key-carol",
                        contactId = 1L,
                        fullName = "Name participant-1",
                        firstName = "Name",
                    ),
                ),
            )

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                val metadata = awaitItem()

                assertEquals("(555) 123-4567", metadata?.otherParticipantDisplayDestination)
                assertEquals(
                    TEST_CALL_ACTION_PHONE_NUMBER,
                    metadata?.otherParticipantNormalizedDestination,
                )
                assertEquals("lookup-key-carol", metadata?.otherParticipantContactLookupKey)
                assertEquals(
                    "content://contacts/people/1/photo",
                    metadata?.otherParticipantPhotoUri,
                )

                cancelAndIgnoreRemainingEvents()
            }

            assertEquals(
                ParticipantData.ParticipantsQuery.PROJECTION.toList(),
                participantsProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMetadata_returnsNullWhenCursorIsEmpty() {
        runTest(
            context = mainDispatcherRule.testDispatcher,
        ) {
            val registeredObservers = mutableListOf<ContentObserver>()
            val capturedProjections = mutableListOf<Array<String>?>()
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubObserverRegistration(
                registeredObservers = registeredObservers,
                expectedUri = expectedUri,
            )
            stubQuery(
                expectedUri = expectedUri,
                capturedProjections = capturedProjections,
                result = createConversationMetadataCursor(row = null),
            )

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                assertEquals(null, awaitItem())
                cancelAndIgnoreRemainingEvents()
            }

            assertEquals(
                ConversationListItemData.PROJECTION.toList(),
                capturedProjections.single()?.toList(),
            )
        }
    }

    @Test
    fun getConversationMetadata_reEmitsWithSnoozeStateWhenSnoozeChanges() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubObserverRegistration(
                registeredObservers = mutableListOf(),
                expectedUri = expectedUri,
            )
            stubFreshMetadataCursorPerQuery(expectedUri = expectedUri)

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                assertEquals(false, awaitItem()?.isSnoozed)

                isSnoozedFlow.value = true

                assertEquals(true, awaitItem()?.isSnoozed)
                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMetadata_carrierAlias_becomesEditableOnceCarrierConfigLoads() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()
            stubObserverRegistration(
                registeredObservers = mutableListOf(),
                expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                    CONVERSATION_ID.value
                ),
            )
            stubOneOnOneConversation(otherParticipantDestination = "john.doe")

            repository.getConversationMetadata(conversationId = CONVERSATION_ID).test {
                assertEquals(
                    ConversationComposerAvailability.Unavailable(
                        reason = ConversationComposerDisabledReason.READ_ONLY_CONVERSATION,
                    ),
                    awaitItem()?.composerAvailability,
                )

                stubMmsConfig(subId = SUB_ID, aliasEnabled = true)
                mmsConfigLoadCount.update { count -> count + 1 }

                assertEquals(
                    ConversationComposerAvailability.Editable,
                    awaitItem()?.composerAvailability,
                )
                cancelAndIgnoreRemainingEvents()
            }
        }
    }

    @Test
    fun getConversationMetadataSnapshot_includesSnoozeState() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()
            val expectedUri = MessagingContentProvider.buildConversationMetadataUri(
                CONVERSATION_ID.value
            )

            stubFreshMetadataCursorPerQuery(expectedUri = expectedUri)
            isSnoozedFlow.value = true

            val metadata = repository.getConversationMetadataSnapshot(
                conversationId = CONVERSATION_ID,
            )

            assertEquals(true, metadata?.isSnoozed)
        }
    }

    @Test
    fun getConversationMetadataSnapshot_senderThatCannotReceiveMessages_isReadOnly() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()
            stubOneOnOneConversation(otherParticipantDestination = "AMAZON")

            val metadata = repository.getConversationMetadataSnapshot(
                conversationId = CONVERSATION_ID,
            )

            assertEquals(
                ConversationComposerAvailability.Unavailable(
                    reason = ConversationComposerDisabledReason.READ_ONLY_CONVERSATION,
                ),
                metadata?.composerAvailability,
            )
        }
    }

    @Test
    fun getConversationMetadataSnapshot_senderWithAPhoneNumber_isEditable() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()
            stubOneOnOneConversation(otherParticipantDestination = TEST_CALL_ACTION_PHONE_NUMBER)

            val metadata = repository.getConversationMetadataSnapshot(
                conversationId = CONVERSATION_ID,
            )

            assertEquals(
                ConversationComposerAvailability.Editable,
                metadata?.composerAvailability,
            )
        }
    }

    @Test
    fun getConversationMetadataSnapshot_carrierAliasOnASimThatSupportsAliases_isEditable() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            stubMmsConfig(subId = SUB_ID, aliasEnabled = true)
            val repository = createRepository()
            stubOneOnOneConversation(otherParticipantDestination = "john.doe")

            val metadata = repository.getConversationMetadataSnapshot(
                conversationId = CONVERSATION_ID,
            )

            assertEquals(
                ConversationComposerAvailability.Editable,
                metadata?.composerAvailability,
            )
        }
    }

    private fun stubOneOnOneConversation(otherParticipantDestination: String) {
        every {
            contentResolver.query(
                MessagingContentProvider.buildConversationMetadataUri(CONVERSATION_ID.value),
                any(),
                null,
                null,
                null,
            )
        } answers {
            createConversationMetadataCursor(
                row = conversationMetadataRow(
                    conversationName = otherParticipantDestination,
                    selfParticipantId = "self-2",
                    participantCount = 1,
                    otherParticipantNormalizedDestination = otherParticipantDestination,
                ),
            )
        }
        every {
            contentResolver.query(
                MessagingContentProvider.buildConversationParticipantsUri(CONVERSATION_ID.value),
                any(),
                null,
                null,
                null,
            )
        } answers {
            createParticipantsCursor(
                participantRow(
                    participantId = "participant-1",
                    subId = ParticipantData.OTHER_THAN_SELF_SUB_ID,
                    displayDestination = otherParticipantDestination,
                    normalizedDestination = otherParticipantDestination,
                    profilePhotoUri = "",
                    lookupKey = "",
                    contactId = -1L,
                    fullName = "",
                    firstName = "",
                ),
            )
        }
    }

    private fun stubFreshMetadataCursorPerQuery(expectedUri: Uri) {
        every {
            contentResolver.query(expectedUri, any(), null, null, null)
        } answers {
            createConversationMetadataCursor(
                row = conversationMetadataRow(
                    conversationName = "Carol, Dave",
                    selfParticipantId = "self-2",
                    participantCount = 2,
                ),
            )
        }
    }

    private fun createConversationMetadataCursor(row: TestConversationMetadataRow?): Cursor {
        val cursor = MatrixCursor(ConversationListItemData.PROJECTION)

        if (row != null) {
            cursor.addRow(
                ConversationListItemData.PROJECTION.map { columnName ->
                    row.toColumnValues()[columnName]
                }.toTypedArray(),
            )
        }

        return cursor
    }

    private fun conversationMetadataRow(
        conversationName: String,
        selfParticipantId: String,
        participantCount: Int,
        isArchived: Boolean = false,
        otherParticipantLookupKey: String = "",
        otherParticipantNormalizedDestination: String = "",
    ): TestConversationMetadataRow {
        return TestConversationMetadataRow(
            conversationName = conversationName,
            selfParticipantId = selfParticipantId,
            participantCount = participantCount,
            isArchived = isArchived,
            otherParticipantLookupKey = otherParticipantLookupKey,
            otherParticipantNormalizedDestination = otherParticipantNormalizedDestination,
        )
    }

    private data class TestConversationMetadataRow(
        val conversationName: String,
        val selfParticipantId: String,
        val participantCount: Int,
        val isArchived: Boolean = false,
        val otherParticipantLookupKey: String = "",
        val otherParticipantNormalizedDestination: String = "",
    ) {
        fun toColumnValues(): Map<String, Any?> {
            return mapOf(
                ConversationColumns._ID to CONVERSATION_ID,
                ConversationColumns.NAME to conversationName,
                ConversationColumns.ICON to "",
                ConversationColumns.SNIPPET_TEXT to "",
                ConversationColumns.SORT_TIMESTAMP to 0L,
                MessageColumns.READ to 1,
                ConversationColumns.PREVIEW_URI to "",
                ConversationColumns.PREVIEW_CONTENT_TYPE to "",
                ConversationColumns.PARTICIPANT_CONTACT_ID to -1L,
                ConversationColumns.PARTICIPANT_LOOKUP_KEY to otherParticipantLookupKey,
                ConversationColumns.OTHER_PARTICIPANT_NORMALIZED_DESTINATION to
                    otherParticipantNormalizedDestination,
                ConversationColumns.PARTICIPANT_COUNT to participantCount,
                ConversationColumns.CURRENT_SELF_ID to selfParticipantId,
                ConversationColumns.NOTIFICATION_ENABLED to 1,
                ConversationColumns.NOTIFICATION_SOUND_URI to "",
                ConversationColumns.NOTIFICATION_VIBRATION to 0,
                ConversationColumns.INCLUDE_EMAIL_ADDRESS to 0,
                MessageColumns.STATUS to MessageData.BUGLE_STATUS_INCOMING_COMPLETE,
                ConversationColumns.SHOW_DRAFT to 0,
                ConversationColumns.DRAFT_PREVIEW_URI to "",
                ConversationColumns.DRAFT_PREVIEW_CONTENT_TYPE to "",
                ConversationColumns.DRAFT_SNIPPET_TEXT to "",
                ConversationColumns.ARCHIVE_STATUS to if (isArchived) 1 else 0,
                MessageColumns._ID to "message-1",
                ConversationColumns.SUBJECT_TEXT to "",
                ConversationColumns.DRAFT_SUBJECT_TEXT to "",
                MessageColumns.RAW_TELEPHONY_STATUS to 0,
                "snippet_sender_first_name" to "",
                "snippet_sender_display_destination" to "",
                ConversationColumns.IS_ENTERPRISE to 0,
            )
        }
    }

    private companion object {
        const val SUB_ID = 1
    }
}
