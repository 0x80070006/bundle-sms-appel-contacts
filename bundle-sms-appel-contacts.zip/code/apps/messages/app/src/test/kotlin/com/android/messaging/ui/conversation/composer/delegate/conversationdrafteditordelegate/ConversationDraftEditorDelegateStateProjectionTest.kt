package com.android.messaging.ui.conversation.composer.delegate.conversationdrafteditordelegate

import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.data.conversation.model.ParticipantId
import com.android.messaging.domain.conversation.usecase.draft.model.ConversationDraftSendProtocol
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import com.android.messaging.testutil.assertThat
import com.android.messaging.testutil.typeMessageText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

internal class ConversationDraftEditorDelegateStateProjectionTest :
    BaseConversationDraftEditorDelegateTest() {

    @Test
    fun onMessageTextChanged_reflectsTextInVisibleStateAndKeepsSmsProtocol() {
        val delegate = loadedDelegate()

        delegate.typeMessageText(messageText = "hello")

        assertEquals("hello", delegate.state.value.draft.messageText)
        assertEquals(ConversationDraftSendProtocol.SMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun onSubjectTextChanged_makesDraftMmsAndResolvesVisibleProtocolToMms() {
        val delegate = loadedDelegate()

        delegate.onSubjectTextChanged(subjectText = "subject")

        assertEquals("subject", delegate.state.value.draft.subjectText)
        assertEquals(ConversationDraftSendProtocol.MMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun onSelfParticipantIdChanged_reflectsParticipantWithoutPromotingToMms() {
        val delegate = loadedDelegate()

        delegate.onSelfParticipantIdChanged(
            conversationId = CONVERSATION_ID,
            selfParticipantId = ParticipantId("self-2"),
        )

        assertThat(delegate.state.value.draft.selfParticipantId).isEqualTo(ParticipantId("self-2"))
        assertEquals(ConversationDraftSendProtocol.SMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun removingLastAttachment_emptiesDraftAndResetsProtocolToSms() {
        val delegate = loadedDelegate(
            persistedDraft = draft(attachments = listOf(attachment(contentUri = "content://a/1"))),
        )
        assertEquals(ConversationDraftSendProtocol.MMS, delegate.state.value.sendProtocol)

        delegate.removeAttachment(contentUri = "content://a/1")

        assertTrue(delegate.state.value.draft.attachments.isEmpty())
        assertEquals(ConversationDraftSendProtocol.SMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun clearingSubjectWhileTextRemains_downgradesMmsToSms() {
        val delegate = loadedDelegate(
            persistedDraft = draft(messageText = "hi", subjectText = "subject"),
        )
        assertEquals(ConversationDraftSendProtocol.MMS, delegate.state.value.sendProtocol)

        delegate.onSubjectTextChanged(subjectText = "")

        assertEquals(ConversationDraftSendProtocol.SMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun textEditAfterAppliedSendProtocol_preservesResolvedProtocolForTextDraft() {
        val delegate = loadedDelegate()
        delegate.typeMessageText(messageText = "hi")
        delegate.applySendProtocol(sendProtocol = ConversationDraftSendProtocol.MMS)
        assertEquals(ConversationDraftSendProtocol.MMS, delegate.state.value.sendProtocol)

        delegate.typeMessageText(messageText = "hi there")

        assertEquals(ConversationDraftSendProtocol.MMS, delegate.state.value.sendProtocol)
    }

    @Test
    fun reset_marksVisibleDraftAsCheckingUntilPersistedDraftArrives() {
        val delegate = createDelegate()

        delegate.reset(conversationId = ConversationId("conversation-loading"))
        assertTrue(delegate.state.value.draft.isCheckingDraft)

        delegate.applyPersistedDraftUpdate(
            persistedDraftUpdate = persistedDraftUpdate(
                conversationId = ConversationId("conversation-loading"),
            ),
        )
        assertFalse(delegate.state.value.draft.isCheckingDraft)
    }
}
