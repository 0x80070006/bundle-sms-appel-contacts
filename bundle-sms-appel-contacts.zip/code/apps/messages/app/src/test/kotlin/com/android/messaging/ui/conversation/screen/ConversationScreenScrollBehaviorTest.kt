package com.android.messaging.ui.conversation.screen

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performScrollToIndex
import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.data.conversation.model.MessageId
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import com.android.messaging.ui.conversation.CONVERSATION_MESSAGES_LIST_TEST_TAG
import com.android.messaging.ui.conversation.conversationMessageItemTestTag
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
internal class ConversationScreenScrollBehaviorTest : BaseConversationScreenTest() {

    @Test
    fun outgoingInsert_scrollsToLatestMessage() {
        val screenModel = createScreenModel()
        screenModel.scaffoldUiStateFlow.value = createPresentUiState(
            messages = createMessages(
                count = 30,
                latestMessageId = "message-30",
                latestMessageIncoming = false,
            ),
        )

        setContent(screenModel = screenModel.model)
        composeTestRule
            .onNodeWithTag(CONVERSATION_MESSAGES_LIST_TEST_TAG)
            .performScrollToIndex(index = 20)
        composeTestRule.waitForIdle()

        screenModel.scaffoldUiStateFlow.value = createPresentUiState(
            messages = createMessages(
                count = 31,
                latestMessageId = "message-31",
                latestMessageIncoming = false,
            ),
        )
        composeTestRule.waitForIdle()

        composeTestRule
            .onNodeWithTag(conversationMessageItemTestTag(messageId = MessageId("message-31")))
            .assertIsDisplayed()
    }

    @Test
    fun conversationChange_resetsListStateToLatestMessage() {
        val screenModel = createScreenModel()
        var activeConversationId by mutableStateOf(CONVERSATION_ID)
        screenModel.scaffoldUiStateFlow.value = createPresentUiState(
            messages = createMessages(
                count = 30,
                latestMessageId = "conversation-1-message-30",
                latestMessageIncoming = false,
                messageIdPrefix = "conversation-1-message",
            ),
        )

        setContent(
            screenModel = screenModel.model,
            conversationId = { activeConversationId },
        )

        composeTestRule
            .onNodeWithTag(CONVERSATION_MESSAGES_LIST_TEST_TAG)
            .performScrollToIndex(index = 20)
        composeTestRule.waitForIdle()
        composeTestRule
            .onNodeWithTag(
                conversationMessageItemTestTag(messageId = MessageId("conversation-1-message-30"))
            )
            .assertDoesNotExist()

        composeTestRule.runOnIdle {
            activeConversationId = ConversationId("conversation-2")
            screenModel.scaffoldUiStateFlow.value = createPresentUiState(
                messages = createMessages(
                    count = 5,
                    latestMessageId = "conversation-2-message-5",
                    latestMessageIncoming = false,
                    messageIdPrefix = "conversation-2-message",
                ),
            )
        }
        composeTestRule.waitForIdle()

        composeTestRule
            .onNodeWithTag(
                conversationMessageItemTestTag(messageId = MessageId("conversation-2-message-5"))
            )
            .assertIsDisplayed()
    }

    @Test
    fun pendingScrollMessageId_anchorsTargetMessage_andInvokesConsumed() {
        val screenModel = createScreenModel()
        screenModel.scaffoldUiStateFlow.value = createPresentUiState(
            messages = createMessages(
                count = 50,
                latestMessageId = "message-50",
                latestMessageIncoming = false,
            ),
        )
        var consumedCount = 0

        setContent(
            screenModel = screenModel.model,
            pendingScrollMessageId = MessageId("message-45"),
            onPendingScrollMessageIdConsumed = { consumedCount += 1 },
        )

        composeTestRule.waitForIdle()

        composeTestRule
            .onNodeWithTag(conversationMessageItemTestTag(messageId = MessageId("message-45")))
            .assertIsDisplayed()
        composeTestRule.runOnIdle {
            assertEquals(1, consumedCount)
        }
    }

    @Test
    fun nullPendingScrollMessageId_doesNotInvokeConsumed() {
        val screenModel = createScreenModel()
        screenModel.scaffoldUiStateFlow.value = createPresentUiState(
            messages = createMessages(
                count = 8,
                latestMessageId = "message-8",
                latestMessageIncoming = false,
            ),
        )
        var consumedCount = 0

        setContent(
            screenModel = screenModel.model,
            pendingScrollMessageId = null,
            onPendingScrollMessageIdConsumed = { consumedCount += 1 },
        )

        composeTestRule.waitForIdle()

        composeTestRule.runOnIdle {
            assertEquals(0, consumedCount)
        }
    }

    @Test
    fun missingPendingScrollMessageId_consumesOnceWithoutChangingVisibleItem() {
        val screenModel = createScreenModel()
        val uiState = createPresentUiState(
            messages = createMessages(
                count = 50,
                latestMessageId = "message-50",
                latestMessageIncoming = false,
            ),
        )
        screenModel.scaffoldUiStateFlow.value = uiState
        var consumedCount = 0

        setContent(
            screenModel = screenModel.model,
            pendingScrollMessageId = MessageId("missing-message"),
            onPendingScrollMessageIdConsumed = { consumedCount += 1 },
        )

        composeTestRule.waitForIdle()

        composeTestRule
            .onNodeWithTag(conversationMessageItemTestTag(messageId = MessageId("message-50")))
            .assertIsDisplayed()
        composeTestRule.runOnIdle {
            assertEquals(1, consumedCount)
            screenModel.scaffoldUiStateFlow.value = uiState.copy(isBlocked = true)
        }
        composeTestRule.waitForIdle()

        composeTestRule
            .onNodeWithTag(conversationMessageItemTestTag(messageId = MessageId("message-50")))
            .assertIsDisplayed()
        composeTestRule.runOnIdle {
            assertEquals(1, consumedCount)
        }
    }
}
