package com.android.messaging.data.conversation.repository.conversations

import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.data.conversation.model.MessageId
import com.android.messaging.datamodel.action.DeleteConversationAction
import com.android.messaging.datamodel.action.DeleteMessageAction
import com.android.messaging.datamodel.action.RedownloadMmsAction
import com.android.messaging.datamodel.action.ResendMessageAction
import com.android.messaging.datamodel.action.UpdateConversationArchiveStatusAction
import io.mockk.every
import io.mockk.just
import io.mockk.mockkStatic
import io.mockk.runs
import io.mockk.unmockkAll
import io.mockk.verify
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
internal class ConversationsRepositoryActionsTest : BaseConversationsRepositoryTest() {

    @Before
    fun setUpActions() {
        mockkStatic(DeleteMessageAction::class)
        mockkStatic(RedownloadMmsAction::class)
        mockkStatic(ResendMessageAction::class)
        mockkStatic(UpdateConversationArchiveStatusAction::class)
        mockkStatic(DeleteConversationAction::class)
        every { DeleteMessageAction.deleteMessage(any()) } just runs
        every { RedownloadMmsAction.redownloadMessage(any()) } just runs
        every { ResendMessageAction.resendMessage(any()) } just runs
        every { UpdateConversationArchiveStatusAction.archiveConversation(any()) } just runs
        every { UpdateConversationArchiveStatusAction.unarchiveConversation(any()) } just runs
        every { DeleteConversationAction.deleteConversation(any(), any()) } just runs
        every { DeleteConversationAction.deleteConversations(any()) } just runs
    }

    @After
    fun tearDownActions() {
        unmockkAll()
    }

    @Test
    fun deleteMessages_skipsBlankIdsAndDelegatesNonBlankIds() {
        createRepository().deleteMessages(
            messageIds = listOf(
                MessageId("message-1"),
                MessageId(""),
                MessageId(" "),
                MessageId("message-2")
            ),
        )

        verify(exactly = 1) {
            DeleteMessageAction.deleteMessage("message-1")
        }
        verify(exactly = 1) {
            DeleteMessageAction.deleteMessage("message-2")
        }
        verify(exactly = 0) {
            DeleteMessageAction.deleteMessage("")
        }
        verify(exactly = 0) {
            DeleteMessageAction.deleteMessage(" ")
        }
    }

    @Test
    fun messageActions_skipBlankIdsAndDelegateNonBlankIds() {
        val repository = createRepository()

        repository.downloadMessage(messageId = MessageId(""))
        repository.downloadMessage(messageId = MessageId("message-download"))
        repository.resendMessage(messageId = MessageId(" "))
        repository.resendMessage(messageId = MessageId("message-resend"))

        verify(exactly = 0) {
            RedownloadMmsAction.redownloadMessage("")
        }
        verify(exactly = 1) {
            RedownloadMmsAction.redownloadMessage("message-download")
        }
        verify(exactly = 0) {
            ResendMessageAction.resendMessage(" ")
        }
        verify(exactly = 1) {
            ResendMessageAction.resendMessage("message-resend")
        }
    }

    @Test
    fun archiveActions_skipBlankIdsAndDelegateNonBlankIds() {
        runTest(context = mainDispatcherRule.testDispatcher) {
            val repository = createRepository()

            repository.archiveConversation(conversationId = ConversationId(""))
            repository.archiveConversation(conversationId = ConversationId("conversation-archive"))
            repository.unarchiveConversation(conversationId = ConversationId(" "))
            repository.unarchiveConversation(
                conversationId = ConversationId("conversation-unarchive")
            )

            io.mockk.coVerify(exactly = 0) {
                conversationArchiveStore.archiveConversation(ConversationId(""))
            }
            io.mockk.coVerify(exactly = 1) {
                conversationArchiveStore.archiveConversation(ConversationId("conversation-archive"))
            }
            io.mockk.coVerify(exactly = 0) {
                conversationArchiveStore.unarchiveConversation(ConversationId(" "))
            }
            io.mockk.coVerify(exactly = 1) {
                conversationArchiveStore.unarchiveConversation(
                    ConversationId("conversation-unarchive")
                )
            }
        }
    }

    @Test
    fun deleteConversation_skipsBlankIdAndDelegatesNonBlankIdWithCutoff() {
        val repository = createRepository()

        repository.deleteConversation(conversationId = ConversationId(""), cutoffTimestamp = 123L)
        repository.deleteConversation(
            conversationId = ConversationId("conversation-delete"),
            cutoffTimestamp = 456L,
        )

        verify(exactly = 0) {
            DeleteConversationAction.deleteConversation("", 123L)
        }
        verify(exactly = 1) {
            DeleteConversationAction.deleteConversation("conversation-delete", 456L)
        }
    }

    @Test
    fun deleteConversations_skipsBlankIdsAndDelegatesTheRestInOneBatch() {
        val repository = createRepository()

        repository.deleteConversations(
            cutoffTimestampsByConversationId = mapOf(
                ConversationId("conversation-1") to 123L,
                ConversationId(" ") to 456L,
                ConversationId("conversation-2") to 789L,
            ),
        )

        verify(exactly = 1) {
            DeleteConversationAction.deleteConversations(
                mapOf(
                    "conversation-1" to 123L,
                    "conversation-2" to 789L,
                ),
            )
        }
    }

    @Test
    fun deleteConversations_skipsTheActionWhenEveryIdIsBlank() {
        createRepository().deleteConversations(
            cutoffTimestampsByConversationId = mapOf(ConversationId("") to 123L),
        )

        verify(exactly = 0) {
            DeleteConversationAction.deleteConversations(any())
        }
    }
}
