package com.android.messaging.ui.conversation.messages.delegate.conversationmessagesdelegate

import android.net.Uri
import android.os.Parcel
import androidx.lifecycle.SavedStateHandle
import com.android.messaging.data.appsettings.repository.AppSettingsRepository
import com.android.messaging.data.conversation.model.ConversationId
import com.android.messaging.data.conversation.model.MessageId
import com.android.messaging.data.conversation.model.attachment.ConversationVCardAttachmentMetadata
import com.android.messaging.data.conversation.model.attachment.ConversationVCardAttachmentType
import com.android.messaging.data.conversation.model.message.ConversationMessagesWindow
import com.android.messaging.data.conversation.repository.ConversationVCardMetadataRepository
import com.android.messaging.data.conversation.repository.ConversationsRepository
import com.android.messaging.datamodel.data.ConversationMessageData
import com.android.messaging.domain.media.usecase.ResolveAudioDurationMillis
import com.android.messaging.testutil.MainDispatcherRule
import com.android.messaging.testutil.TEST_CONVERSATION_ID as CONVERSATION_ID
import com.android.messaging.ui.conversation.attachment.mapper.ConversationVCardAttachmentUiModelMapper
import com.android.messaging.ui.conversation.attachment.model.ConversationVCardAttachmentUiModel
import com.android.messaging.ui.conversation.messages.delegate.ConversationMessagesDelegateImpl
import com.android.messaging.ui.conversation.messages.mapper.ConversationMessageUiModelMapper
import com.android.messaging.ui.conversation.messages.model.message.ConversationMessagePartUiModel
import com.android.messaging.ui.conversation.messages.model.message.ConversationMessageUiModel
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.TestScope
import org.junit.Rule

internal abstract class BaseConversationMessagesDelegateTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    protected val conversationsRepository = mockk<ConversationsRepository>()
    protected val appSettingsRepository = mockk<AppSettingsRepository> {
        coEvery { isYouTubeLinkPreviewsEnabled() } returns false
        coEvery { isWebLinkPreviewsEnabled() } returns false
    }
    protected val resolveAudioDurationMillis =
        mockk<ResolveAudioDurationMillis>(relaxed = true)
    protected val messageUiModelMapper = mockk<ConversationMessageUiModelMapper>()
    protected val vCardUiModelMapper = mockk<ConversationVCardAttachmentUiModelMapper>()
    protected val vCardMetadataRepository = mockk<ConversationVCardMetadataRepository>()
    protected val savedStateHandle = SavedStateHandle()

    protected fun createDelegate(
        savedStateHandle: SavedStateHandle = this.savedStateHandle,
        defaultDispatcher: CoroutineDispatcher = mainDispatcherRule.testDispatcher,
    ): ConversationMessagesDelegateImpl {
        return ConversationMessagesDelegateImpl(
            conversationsRepository = conversationsRepository,
            appSettingsRepository = appSettingsRepository,
            resolveAudioDurationMillis = resolveAudioDurationMillis,
            conversationMessageUiModelMapper = messageUiModelMapper,
            conversationVCardAttachmentUiModelMapper = vCardUiModelMapper,
            conversationVCardMetadataRepository = vCardMetadataRepository,
            savedStateHandle = savedStateHandle,
            defaultDispatcher = defaultDispatcher,
        )
    }

    protected fun TestScope.createBoundDelegate(
        conversationIdFlow: StateFlow<ConversationId?>,
        savedStateHandle: SavedStateHandle =
            this@BaseConversationMessagesDelegateTest.savedStateHandle,
        defaultDispatcher: CoroutineDispatcher = mainDispatcherRule.testDispatcher,
    ): ConversationMessagesDelegateImpl {
        return createDelegate(
            savedStateHandle = savedStateHandle,
            defaultDispatcher = defaultDispatcher,
        ).also { delegate ->
            delegate.bind(scope = backgroundScope, conversationIdFlow = conversationIdFlow)
        }
    }

    /** What a restored process is handed: these values, through what the framework saves. */
    protected fun SavedStateHandle.afterProcessDeath(): SavedStateHandle {
        val parcel = Parcel.obtain()

        return try {
            parcel.writeBundle(savedStateProvider().saveState())
            parcel.setDataPosition(0)
            SavedStateHandle.createHandle(parcel.readBundle(), null)
        } finally {
            parcel.recycle()
        }
    }

    protected fun givenConversationMessages(
        messages: Flow<List<ConversationMessageData>>,
        conversationId: ConversationId = CONVERSATION_ID,
        hasMore: Boolean = false,
    ) {
        every {
            conversationsRepository.getConversationMessages(
                conversationId = conversationId,
                windowSizes = any(),
            )
        } returns messages.map { currentMessages ->
            ConversationMessagesWindow(messages = currentMessages, hasMore = hasMore)
        }
    }

    protected fun givenVCardMetadata(
        contentUri: String,
        metadata: Flow<ConversationVCardAttachmentMetadata>,
    ) {
        every {
            vCardMetadataRepository.observeAttachmentMetadata(
                contentUri = contentUri,
                refreshes = any(),
            )
        } returns metadata
    }

    protected fun givenVCardUiModel(
        metadata: ConversationVCardAttachmentMetadata?,
        uiModel: ConversationVCardAttachmentUiModel,
    ) {
        every {
            vCardUiModelMapper.map(metadata = metadata)
        } returns uiModel
    }

    protected fun messagesOf(
        vararg uiModels: ConversationMessageUiModel,
    ): List<ConversationMessageData> {
        return uiModels.map { uiModel ->
            mockk<ConversationMessageData>(relaxed = true).also { data ->
                every { messageUiModelMapper.map(data = data) } returns uiModel
            }
        }
    }

    protected fun messageUiModel(
        messageId: String,
        parts: List<ConversationMessagePartUiModel> = emptyList(),
    ): ConversationMessageUiModel {
        return ConversationMessageUiModel(
            messageId = MessageId(messageId),
            conversationId = CONVERSATION_ID,
            text = "Hello",
            parts = parts.toImmutableList(),
            sentTimestamp = 1L,
            receivedTimestamp = 1L,
            displayTimestamp = 1L,
            status = ConversationMessageUiModel.Status.Outgoing.Complete,
            isIncoming = false,
            senderDisplayName = null,
            senderAvatarUri = null,
            senderContactId = 0L,
            senderContactLookupKey = null,
            senderNormalizedDestination = null,
            senderParticipantId = null,
            selfParticipantId = null,
            canClusterWithPrevious = false,
            canClusterWithNext = false,
            canCopyMessageToClipboard = false,
            canDownloadMessage = false,
            canForwardMessage = false,
            canResendMessage = false,
            canSaveAttachments = false,
            mmsDownload = null,
            mmsSubject = null,
            protocol = ConversationMessageUiModel.Protocol.SMS,
        )
    }

    protected fun textPart(text: String = "body"): ConversationMessagePartUiModel.Text {
        return ConversationMessagePartUiModel.Text(text = text)
    }

    protected fun imagePart(
        contentUri: String = "content://media/image/1",
    ): ConversationMessagePartUiModel.Attachment.Image {
        return ConversationMessagePartUiModel.Attachment.Image(
            text = null,
            contentType = "image/jpeg",
            contentUri = Uri.parse(contentUri),
            width = 640,
            height = 480,
        )
    }

    protected fun audioPart(
        contentUri: String? = "content://media/audio/1",
        durationMillis: Long = 0L,
    ): ConversationMessagePartUiModel.Attachment.Audio {
        return ConversationMessagePartUiModel.Attachment.Audio(
            text = null,
            contentType = "audio/mpeg",
            contentUri = contentUri?.let(Uri::parse),
            width = 0,
            height = 0,
            durationMillis = durationMillis,
        )
    }

    protected fun filePart(
        contentUri: String = "content://media/file/1",
    ): ConversationMessagePartUiModel.Attachment.File {
        return ConversationMessagePartUiModel.Attachment.File(
            text = null,
            contentType = "application/pdf",
            contentUri = Uri.parse(contentUri),
            width = 0,
            height = 0,
        )
    }

    protected fun videoPart(
        contentUri: String = "content://media/video/1",
    ): ConversationMessagePartUiModel.Attachment.Video {
        return ConversationMessagePartUiModel.Attachment.Video(
            text = null,
            contentType = "video/mp4",
            contentUri = Uri.parse(contentUri),
            width = 1280,
            height = 720,
        )
    }

    protected fun vCardPart(
        contentUri: String?,
        vCardUiModel: ConversationVCardAttachmentUiModel = vCardUiModel(titleText = "original"),
    ): ConversationMessagePartUiModel.Attachment.VCard {
        return ConversationMessagePartUiModel.Attachment.VCard(
            text = null,
            contentType = "text/x-vCard",
            contentUri = contentUri?.let(Uri::parse),
            width = 0,
            height = 0,
            vCardUiModel = vCardUiModel,
        )
    }

    protected fun vCardUiModel(titleText: String): ConversationVCardAttachmentUiModel {
        return ConversationVCardAttachmentUiModel(
            type = ConversationVCardAttachmentType.CONTACT,
            titleText = titleText,
        )
    }
}
